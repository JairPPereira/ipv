package com.unitv.player;

import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Proxy nativo de mídia: https://mengoplayer.app/__px/<http|https>/<host>/<caminho>
 * - Resolve CORS (a resposta vem da mesma origem da interface).
 * - Libera fluxos HTTP (cleartext) mesmo quando o manifesto bloqueia: http:// usa socket próprio.
 * - Repassa Range (avanço/retrocesso em MP4) e segue redirecionamentos.
 * - Reescreve playlists M3U8 para URLs absolutas do proxy (segmentos, chaves, sub-playlists).
 */
final class MediaProxy {
    private MediaProxy() {}

    static final String PREFIX = "/__px/";
    private static final int TIMEOUT = 20000;
    private static final Charset UTF8 = Charset.forName("UTF-8");

    static boolean handles(Uri u) {
        return u != null && "mengoplayer.app".equals(u.getHost()) && u.getEncodedPath() != null
                && u.getEncodedPath().startsWith(PREFIX);
    }

    /** Converte a URL do proxy na URL real. */
    static String target(String proxyUrl) {
        int i = proxyUrl.indexOf(PREFIX);
        String rest = proxyUrl.substring(i + PREFIX.length());
        int s = rest.indexOf('/');
        if (s < 0) return null;
        String scheme = rest.substring(0, s);
        if (!"http".equals(scheme) && !"https".equals(scheme)) return null;
        return scheme + "://" + rest.substring(s + 1);
    }

    static String wrap(String base, String real) {
        if (real.startsWith("http://")) return base + "__px/http/" + real.substring(7);
        if (real.startsWith("https://")) return base + "__px/https/" + real.substring(8);
        return real;
    }

    static WebResourceResponse serve(WebResourceRequest req, String base) {
        String real = target(req.getUrl().toString());
        if (real == null) return error(400, "Bad Request");
        if (!"GET".equalsIgnoreCase(req.getMethod()) && !"HEAD".equalsIgnoreCase(req.getMethod())) {
            if ("OPTIONS".equalsIgnoreCase(req.getMethod())) return empty(200);
        }
        Map<String, String> in = req.getRequestHeaders();
        String range = header(in, "Range");
        String ua = header(in, "User-Agent");
        if (ua == null) ua = "Mozilla/5.0 (Linux; Android) MengoPlayer";
        ua = ua.replace("; wv", "");
        try {
            Resp r = fetch(real, range, ua, 0);
            String ct = r.headers.get("content-type");
            String mime = ct == null ? guessMime(r.finalUrl) : ct.split(";")[0].trim();
            String lowerUrl = r.finalUrl.toLowerCase(Locale.US);
            boolean playlist = (mime != null && mime.toLowerCase(Locale.US).contains("mpegurl"))
                    || lowerUrl.contains(".m3u8") || lowerUrl.split("\\?")[0].endsWith(".m3u");
            InputStream body = r.body;
            Map<String, String> out = new HashMap<>();
            out.put("Access-Control-Allow-Origin", "*");
            out.put("Access-Control-Allow-Headers", "*");
            out.put("Access-Control-Expose-Headers", "Content-Length, Content-Range, Accept-Ranges");
            out.put("Cache-Control", "no-cache");
            if (!playlist) {
                BufferedInputStream peek = new BufferedInputStream(body, 16384);
                peek.mark(16);
                byte[] h = new byte[7];
                int n = peek.read(h);
                peek.reset();
                body = peek;
                if (n == 7 && "#EXTM3U".equals(new String(h, UTF8))) playlist = true;
            }
            if (playlist) {
                String text = new String(readAll(body, 4 * 1024 * 1024), UTF8);
                byte[] rewritten = rewritePlaylist(text, r.finalUrl, base).getBytes(UTF8);
                out.put("Content-Length", String.valueOf(rewritten.length));
                return new WebResourceResponse("application/vnd.apple.mpegurl", "utf-8", 200, "OK", out,
                        new ByteArrayInputStream(rewritten));
            }
            copy(r.headers, out, "content-length", "Content-Length");
            copy(r.headers, out, "content-range", "Content-Range");
            copy(r.headers, out, "accept-ranges", "Accept-Ranges");
            if (!out.containsKey("Accept-Ranges")) out.put("Accept-Ranges", "bytes");
            int code = r.code;
            if (code >= 300 && code < 400) code = 502;
            String reason = code == 206 ? "Partial Content" : code < 300 ? "OK" : "Error";
            return new WebResourceResponse(mime == null ? "application/octet-stream" : mime, null, code, reason, out, body);
        } catch (Exception e) {
            return error(502, "Bad Gateway");
        }
    }

    /* ---------------- playlist ---------------- */

    static String rewritePlaylist(String text, String baseUrl, String proxyBase) {
        StringBuilder sb = new StringBuilder(text.length() + 256);
        String[] lines = text.split("\r?\n");
        for (String line : lines) {
            String t = line.trim();
            if (t.isEmpty()) { sb.append('\n'); continue; }
            if (t.startsWith("#")) {
                int u = t.indexOf("URI=\"");
                if (u >= 0) {
                    int e = t.indexOf('"', u + 5);
                    if (e > u) {
                        String ref = t.substring(u + 5, e);
                        t = t.substring(0, u + 5) + wrap(proxyBase, resolve(baseUrl, ref)) + t.substring(e);
                    }
                }
                sb.append(t).append('\n');
            } else {
                sb.append(wrap(proxyBase, resolve(baseUrl, t))).append('\n');
            }
        }
        return sb.toString();
    }

    static String resolve(String base, String ref) {
        try { return new URL(new URL(base), ref).toString(); } catch (Exception e) { return ref; }
    }

    /* ---------------- HTTP ---------------- */

    static final class Resp {
        int code; Map<String, String> headers = new HashMap<>(); InputStream body; String finalUrl;
    }

    static Resp fetch(String url, String range, String ua, int depth) throws IOException {
        if (depth > 6) throw new IOException("too many redirects");
        Resp r = url.startsWith("http://") ? rawHttp(url, range, ua) : https(url, range, ua);
        if (r.code >= 300 && r.code < 400 && r.headers.get("location") != null) {
            try { r.body.close(); } catch (Exception ignored) {}
            return fetch(resolve(url, r.headers.get("location")), range, ua, depth + 1);
        }
        return r;
    }

    private static Resp https(String url, String range, String ua) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setInstanceFollowRedirects(false);
        c.setConnectTimeout(TIMEOUT);
        c.setReadTimeout(TIMEOUT);
        c.setRequestProperty("User-Agent", ua);
        c.setRequestProperty("Accept", "*/*");
        c.setRequestProperty("Accept-Encoding", "identity");
        if (range != null) c.setRequestProperty("Range", range);
        Resp r = new Resp();
        r.code = c.getResponseCode();
        for (Map.Entry<String, java.util.List<String>> e : c.getHeaderFields().entrySet()) {
            if (e.getKey() != null && !e.getValue().isEmpty())
                r.headers.put(e.getKey().toLowerCase(Locale.US), e.getValue().get(0));
        }
        r.body = r.code >= 400 ? (c.getErrorStream() != null ? c.getErrorStream() : new ByteArrayInputStream(new byte[0])) : c.getInputStream();
        r.finalUrl = url;
        return r;
    }

    /** Cliente HTTP/1.1 simples por socket — não depende da política de cleartext do manifesto. */
    private static Resp rawHttp(String url, String range, String ua) throws IOException {
        URL u = new URL(url);
        int port = u.getPort() > 0 ? u.getPort() : 80;
        String path = u.getFile();
        if (path == null || path.isEmpty()) path = "/";
        Socket sock = new Socket();
        sock.connect(new InetSocketAddress(u.getHost(), port), TIMEOUT);
        sock.setSoTimeout(TIMEOUT);
        OutputStream os = sock.getOutputStream();
        StringBuilder rq = new StringBuilder();
        rq.append("GET ").append(path).append(" HTTP/1.1\r\n");
        rq.append("Host: ").append(u.getHost()).append(u.getPort() > 0 && u.getPort() != 80 ? ":" + u.getPort() : "").append("\r\n");
        rq.append("User-Agent: ").append(ua).append("\r\n");
        rq.append("Accept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n");
        if (range != null) rq.append("Range: ").append(range).append("\r\n");
        rq.append("\r\n");
        os.write(rq.toString().getBytes(UTF8));
        os.flush();
        final Socket fs = sock;
        InputStream is = new BufferedInputStream(sock.getInputStream(), 32768);
        Resp r = new Resp();
        String status = readLine(is);
        if (status == null || !status.startsWith("HTTP/") && !status.startsWith("ICY")) {
            sock.close(); throw new IOException("bad status");
        }
        String[] sp = status.split(" ");
        r.code = sp.length > 1 ? Integer.parseInt(sp[1].trim()) : 200;
        String line;
        while ((line = readLine(is)) != null && !line.isEmpty()) {
            int c = line.indexOf(':');
            if (c > 0) r.headers.put(line.substring(0, c).trim().toLowerCase(Locale.US), line.substring(c + 1).trim());
        }
        InputStream body = is;
        if ("chunked".equalsIgnoreCase(r.headers.get("transfer-encoding"))) {
            body = new Chunked(is);
            r.headers.remove("content-length");
        }
        r.body = new FilterInputStream(body) {
            @Override public void close() throws IOException { try { super.close(); } finally { fs.close(); } }
        };
        r.finalUrl = url;
        return r;
    }

    private static String readLine(InputStream is) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(128);
        int c;
        while ((c = is.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 16384) throw new IOException("header too long");
        }
        if (c == -1 && b.size() == 0) return null;
        return new String(b.toByteArray(), UTF8);
    }

    private static final class Chunked extends InputStream {
        private final InputStream in; private long left = 0; private boolean eof = false;
        Chunked(InputStream in) { this.in = in; }
        private boolean next() throws IOException {
            if (eof) return false;
            if (left == 0) {
                String l = readLine(in);
                if (l != null && l.isEmpty()) l = readLine(in);
                if (l == null) { eof = true; return false; }
                int sc = l.indexOf(';');
                left = Long.parseLong((sc >= 0 ? l.substring(0, sc) : l).trim(), 16);
                if (left == 0) { eof = true; return false; }
            }
            return true;
        }
        @Override public int read() throws IOException {
            if (!next()) return -1;
            int c = in.read(); if (c >= 0) left--; return c;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (!next()) return -1;
            int n = in.read(b, off, (int) Math.min(len, left));
            if (n > 0) left -= n; return n;
        }
        @Override public void close() throws IOException { in.close(); }
    }

    /* ---------------- util ---------------- */

    private static String header(Map<String, String> h, String k) {
        if (h == null) return null;
        for (Map.Entry<String, String> e : h.entrySet()) if (e.getKey().equalsIgnoreCase(k)) return e.getValue();
        return null;
    }

    private static void copy(Map<String, String> from, Map<String, String> to, String k, String outK) {
        String v = from.get(k); if (v != null) to.put(outK, v);
    }

    static String guessMime(String url) {
        String p = url.split("\\?")[0].toLowerCase(Locale.US);
        if (p.endsWith(".ts")) return "video/mp2t";
        if (p.endsWith(".mp4") || p.endsWith(".m4v") || p.endsWith(".m4s")) return "video/mp4";
        if (p.endsWith(".webm") || p.endsWith(".mkv")) return "video/webm";
        if (p.endsWith(".mp3")) return "audio/mpeg";
        if (p.endsWith(".aac")) return "audio/aac";
        if (p.endsWith(".flv")) return "video/x-flv";
        return "application/octet-stream";
    }

    private static byte[] readAll(InputStream in, int max) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream(65536);
        byte[] buf = new byte[16384]; int n;
        while ((n = in.read(buf)) > 0) { b.write(buf, 0, n); if (b.size() > max) break; }
        in.close();
        return b.toByteArray();
    }

    private static WebResourceResponse error(int code, String reason) {
        Map<String, String> h = new HashMap<>();
        h.put("Access-Control-Allow-Origin", "*");
        return new WebResourceResponse("text/plain", "utf-8", code, reason, h, new ByteArrayInputStream(new byte[0]));
    }

    private static WebResourceResponse empty(int code) { return error(code, "OK"); }
}
