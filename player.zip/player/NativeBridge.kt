package com.unitv.player

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.webkit.JavascriptInterface

/** Ponte JS -> nativo exposta como window.Android (Kotlin). */
class NativeBridge(private val act: MainActivity) {

    @JavascriptInterface fun toast(msg: String) = act.toast(msg)

    @JavascriptInterface fun exitApp() { act.ui.post { act.confirmExit() } }

    @JavascriptInterface fun setOrientation(mode: String) = act.setOrientationMode(mode)

    @JavascriptInterface fun isTv(): Boolean =
        act.isLargeScreenDevice()

    @JavascriptInterface fun deviceInfo(): String =
        "{\"model\":\"${Build.MODEL}\",\"sdk\":${Build.VERSION.SDK_INT},\"tv\":${isTv()}}"

    @JavascriptInterface fun openExternal(url: String, mime: String?) {
        act.ui.post {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(Uri.parse(url), if (mime.isNullOrEmpty()) "video/*" else mime)
                act.startActivity(Intent.createChooser(i, "Abrir com"))
            } catch (e: Exception) { act.toast("Nenhum player externo encontrado") }
        }
    }

    @JavascriptInterface fun setAutoStart(on: Boolean) {
        act.getSharedPreferences("mengoplayer", Context.MODE_PRIVATE).edit().putBoolean("autostart", on).apply()
    }

    @JavascriptInterface fun goBack() { act.ui.post { act.onBackPressed() } }

    @JavascriptInterface fun hideSplash() { act.ui.post { act.hideSplash() } }
}
