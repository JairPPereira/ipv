package com.unitv.player;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

/**
 * MengoPlayer — Activity nativa (sempre na HORIZONTAL).
 * - Interface (HTML/CSS/JS/imagens do MengoPlayer) compilada dentro de WebBundle.java (sem assets/).
 * - Splash nativa, tela cheia imersiva, tela sempre ligada.
 * - Controle remoto/D-pad: setas, OK, BACK, MENU, CH+/CH-, teclas coloridas e 1-4 (abas).
 * - Video em tela cheia nativo (onShowCustomView), seletor de arquivo (importar lista), downloads.
 * - Ponte JS "Android" (NativeBridge) para toast, sair, player externo, orientacao etc.
 */
public class MainActivity extends Activity {

    static final String BASE_URL = "https://mengoplayer.app/";
    private static final int FILE_REQ = 4101;

    WebView web;
    private FrameLayout root;
    private FrameLayout fullscreenBox;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private View splash;
    private ValueCallback<Uri[]> fileCallback;
    private long lastBack = 0;
    final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        applyOrientation();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
                | WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        // Preenche tambem a area do entalhe/camera (notch) no topo — evita a faixa preta.
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.TRANSPARENT);
            getWindow().setNavigationBarColor(Color.TRANSPARENT);
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        web = new WebView(this);
        setupWebView();
        setupMouse();
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        fullscreenBox = new FrameLayout(this);
        fullscreenBox.setBackgroundColor(Color.BLACK);
        fullscreenBox.setVisibility(View.GONE);
        root.addView(fullscreenBox, new FrameLayout.LayoutParams(-1, -1));

        splash = buildSplash();
        root.addView(splash, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        immersive();

        if (state != null) {
            web.restoreState(state);
        } else {
            web.loadDataWithBaseURL(BASE_URL, WebBundle.html(), "text/html", "UTF-8", null);
        }
    }

    private long splashStart;
    private View buildSplash() { splashStart = System.currentTimeMillis(); return new SplashView(this); }

    void hideSplash() {
        if (splash == null) return;
        long wait = 1800 - (System.currentTimeMillis() - splashStart);
        if (wait > 0) { ui.postDelayed(new Runnable() { public void run() { hideSplash(); } }, wait); return; }
        final View v = splash;
        splash = null;
        v.animate().alpha(0f).scaleX(1.08f).scaleY(1.08f).setDuration(600)
                .setInterpolator(new android.view.animation.DecelerateInterpolator()).withEndAction(new Runnable() {
            public void run() { root.removeView(v); web.requestFocus(); }
        }).start();
    }

    private void setupWebView() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setUserAgentString(s.getUserAgentString().replace("; wv", ""));
        if (Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(false);
        if (Build.VERSION.SDK_INT >= 21) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        }
        web.setBackgroundColor(Color.BLACK);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        try {
            s.setRenderPriority(WebSettings.RenderPriority.HIGH);
            s.setLoadsImagesAutomatically(true);
            if (Build.VERSION.SDK_INT >= 23) {
                s.setOffscreenPreRaster(true);
            }
        } catch (Throwable ignored) {}
        web.addJavascriptInterface(new NativeBridge(this), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return handleUrl(r.getUrl().toString());
            }
            @Override
            @SuppressWarnings("deprecation")
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                return handleUrl(url);
            }
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                if (MediaProxy.handles(r.getUrl())) return MediaProxy.serve(r, BASE_URL);
                return super.shouldInterceptRequest(v, r);
            }
            @Override
            public void onPageFinished(WebView v, String url) {
                ui.postDelayed(new Runnable() { public void run() { hideSplash(); } }, 250);
                installPlayerWatcher();
                js("window.__initTvMode&&window.__initTvMode(" + isLargeScreenDevice() + ");");
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback cb) {
                if (customView != null) { cb.onCustomViewHidden(); return; }
                customView = view;
                customCallback = cb;
                fullscreenBox.addView(view, new FrameLayout.LayoutParams(-1, -1));
                fullscreenBox.setVisibility(View.VISIBLE);
                applyOrientation(); // video em tela cheia: horizontal tambem no celular
                immersive();
            }
            @Override
            public void onHideCustomView() { exitCustomView(); }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = cb;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Importar lista"), FILE_REQ);
                } catch (Exception e) {
                    fileCallback = null;
                    toast("Nenhum gerenciador de arquivos disponível");
                    return false;
                }
                return true;
            }
        });

        web.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                if (url.startsWith("blob:") || url.startsWith("data:")) return; // tratado no JS
                try {
                    DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                    String name = URLUtil.guessFileName(url, cd, mime);
                    r.setMimeType(mime);
                    r.addRequestHeader("User-Agent", ua);
                    r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                    r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
                    ((DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE)).enqueue(r);
                    toast("Baixando " + name);
                } catch (Exception e) { toast("Falha no download"); }
            }
        });
    }

    private boolean handleUrl(String url) {
        if (url.startsWith("http://") || url.startsWith("https://") || url.startsWith("about:")
                || url.startsWith("data:") || url.startsWith("blob:")) return false;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Exception ignored) {}
        return true;
    }

    private void exitCustomView() {
        if (customView == null) return;
        fullscreenBox.removeView(customView);
        fullscreenBox.setVisibility(View.GONE);
        customView = null;
        if (customCallback != null) customCallback.onCustomViewHidden();
        customCallback = null;
        applyOrientation();
        immersive();
        web.requestFocus();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ && fileCallback != null) {
            Uri[] r = null;
            if (res == RESULT_OK && data != null && data.getData() != null) r = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(r);
            fileCallback = null;
            return;
        }
        super.onActivityResult(req, res, data);
    }

    /* ---------------- Controle remoto / navegação nativa ---------------- */

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        if (NativeNav.isBackKey(code) || code == KeyEvent.KEYCODE_BACK) {
            if (e.getAction() == KeyEvent.ACTION_UP) onBackPressed();
            return true;
        }
        if (e.getAction() != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(e);

        String nav = NativeNav.forKey(code);
        if (nav != null) {
            js("window.__nativeNav&&window.__nativeNav('" + nav + "')");
            return true;
        }

        String dpadDir = null;
        switch (code) {
            case KeyEvent.KEYCODE_DPAD_UP:
                dpadDir = "up"; break;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                dpadDir = "down"; break;
            case KeyEvent.KEYCODE_DPAD_LEFT:
                dpadDir = "left"; break;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
                dpadDir = "right"; break;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
                dpadDir = "enter"; break;
        }
        if (dpadDir != null) {
            js("window.__tvKey&&window.__tvKey('" + dpadDir + "');");
            return true;
        }

        return super.dispatchKeyEvent(e);
    }

    @Override
    public void onBackPressed() {
        if (customView != null) { exitCustomView(); return; }
        // pergunta ao JS se ele consumiu o "voltar" (fecha modal, player, aba de episódios...)
        web.evaluateJavascript("window.__nativeBack?window.__nativeBack():false", new ValueCallback<String>() {
            public void onReceiveValue(String v) {
                if ("true".equals(v)) return;
                if (web.canGoBack()) { web.goBack(); return; }
                long now = System.currentTimeMillis();
                if (now - lastBack < 2000) { confirmExit(); }
                else { lastBack = now; toast("Pressione VOLTAR novamente para sair"); }
            }
        });
    }

    void confirmExit() {
        new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("Sair do MengoPlayer?")
                .setPositiveButton("Sair", (d, w) -> finish())
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /* ---------------- utilidades ---------------- */

    void js(final String code) {
        ui.post(new Runnable() { public void run() { web.evaluateJavascript(code, null); } });
    }

    void toast(final String msg) {
        ui.post(new Runnable() { public void run() {
            Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show(); } });
    }

    /** true enquanto o player de video (modal #playerModal) estiver aberto. */
    volatile boolean playerOpen = false;

    /**
     * Ponte JS: "player"/"landscape" = player aberto, "portrait"/"app"/"auto" = player fechado.
     * Em TV/PC isso nao muda nada (sempre horizontal).
     */
    void setOrientationMode(final String mode) {
        ui.post(new Runnable() { public void run() {
            String m = mode == null ? "" : mode.toLowerCase();
            if (m.startsWith("player") || m.startsWith("land")) playerOpen = true;
            else if (m.startsWith("port") || m.startsWith("app") || m.startsWith("auto") || m.startsWith("close")) playerOpen = false;
            applyOrientation();
        } });
    }

    /** TV, Android TV box, PC/Chromebook/DeX ou aparelho sem tela de toque = tela grande, fica sempre na horizontal. */
    boolean isLargeScreenDevice() {
        android.content.pm.PackageManager pm = getPackageManager();
        if (pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)) return true;
        if (pm.hasSystemFeature("android.hardware.type.television")) return true;
        if (pm.hasSystemFeature("android.hardware.type.pc")) return true;
        if (!pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TOUCHSCREEN)) return true;
        int ui = getResources().getConfiguration().uiMode & android.content.res.Configuration.UI_MODE_TYPE_MASK;
        if (ui == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION
                || ui == android.content.res.Configuration.UI_MODE_TYPE_DESK) return true;
        // Deteccao por tela ampla sem telefonia (TV Boxes genericas HDMI)
        if (!pm.hasSystemFeature(android.content.pm.PackageManager.FEATURE_TELEPHONY)) {
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            float xInches = dm.widthPixels / (dm.xdpi > 0 ? dm.xdpi : 160f);
            float yInches = dm.heightPixels / (dm.ydpi > 0 ? dm.ydpi : 160f);
            double diag = Math.sqrt(xInches * xInches + yInches * yInches);
            if (diag >= 9.0 || dm.widthPixels >= 1200) return true;
        }
        return false;
    }

    /**
     * Regra de orientacao:
     *  - TV / PC: sempre horizontal.
     *  - Celular/tablet: app livre (retrato ou paisagem, segue a rotacao automatica); o player abre na horizontal.
     */
    void applyOrientation() {
        int want;
        if (isLargeScreenDevice() || playerOpen || customView != null)
            want = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE;
        else
            want = ActivityInfo.SCREEN_ORIENTATION_FULL_USER;
        if (getRequestedOrientation() != want) setRequestedOrientation(want);
    }

    /** Mantido por compatibilidade: agora segue a regra de applyOrientation(). */
    void lockLandscape() { applyOrientation(); }

    /** Observa o modal do player na interface e avisa o nativo quando abre/fecha. */
    private void installPlayerWatcher() {
        web.evaluateJavascript(
            "(function(){if(window.__mpOrient)return;window.__mpOrient=1;var last=null;" +
            "function chk(){var m=document.getElementById('playerModal');" +
            "var open=!!(m&&(m.classList.contains('show')||m.classList.contains('player-fullscreen-fallback')));" +
            "if(open!==last){last=open;try{Android.setOrientation(open?'player':'app');}catch(e){}}}" +
            "new MutationObserver(chk).observe(document.body,{attributes:true,childList:true,subtree:true,attributeFilter:['class']});" +
            "document.addEventListener('shown.bs.modal',chk,true);document.addEventListener('hidden.bs.modal',chk,true);" +
            "chk();})();", null);
    }

    /* ---------------- Mouse ---------------- */

    /** Botao direito = VOLTAR (via JS contextmenu -> Android.goBack); botao "voltar" lateral do mouse = VOLTAR. Roda/hover/clique ficam com o WebView. */
    private void setupMouse() {
        web.setOnGenericMotionListener(new View.OnGenericMotionListener() {
            public boolean onGenericMotion(View v, android.view.MotionEvent ev) {
                if (ev.getActionMasked() == android.view.MotionEvent.ACTION_SCROLL) {
                    float vScroll = ev.getAxisValue(android.view.MotionEvent.AXIS_VSCROLL);
                    float hScroll = ev.getAxisValue(android.view.MotionEvent.AXIS_HSCROLL);
                    if (vScroll != 0 || hScroll != 0) {
                        js("window.__tvScroll&&window.__tvScroll(" + (-hScroll * 40) + "," + (-vScroll * 40) + ");");
                        return true;
                    }
                }
                if (Build.VERSION.SDK_INT >= 23 && ev.getActionMasked() == android.view.MotionEvent.ACTION_BUTTON_PRESS) {
                    int b = ev.getActionButton();
                    if (b == android.view.MotionEvent.BUTTON_BACK || b == android.view.MotionEvent.BUTTON_SECONDARY) {
                        onBackPressed();
                        return true;
                    }
                }
                return false;
            }
        });
        if (Build.VERSION.SDK_INT >= 24) {
            web.setPointerIcon(android.view.PointerIcon.getSystemIcon(this, android.view.PointerIcon.TYPE_ARROW));
        }
    }

    @SuppressWarnings("deprecation")
    void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) immersive(); }

    @Override
    protected void onSaveInstanceState(Bundle out) { super.onSaveInstanceState(out); web.saveState(out); }

    @Override
    protected void onPause() { super.onPause(); web.onPause(); }

    @Override
    protected void onResume() { super.onResume(); applyOrientation(); web.onResume(); immersive(); }

    @Override
    protected void onDestroy() {
        if (web != null) {
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
        }
        super.onDestroy();
    }
}
