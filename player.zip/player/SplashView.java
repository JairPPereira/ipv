package com.unitv.player;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.View;
import android.view.animation.LinearInterpolator;

/** Abertura cinematografica: fundo com brilho radial, logo MengoPlayer com reflexo de luz e barra de carregamento. */
final class SplashView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float t = 0f;
    private final ValueAnimator anim;

    SplashView(Context c) {
        super(c);
        setBackgroundColor(Color.parseColor("#0a0000"));
        anim = ValueAnimator.ofFloat(0f, 1000f);
        anim.setDuration(1000000); anim.setInterpolator(new LinearInterpolator());
        anim.addUpdateListener(a -> { t = (float) a.getCurrentPlayTime() / 1000f; invalidate(); });
        anim.start();
    }

    @Override protected void onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow(); }

    private static float ease(float x) { x = Math.max(0, Math.min(1, x)); return 1 - (float) Math.pow(1 - x, 3); }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight(); float cx = w / 2f, cy = h / 2f, u = Math.min(w, h);
        // brilho radial pulsante
        float pulse = 0.85f + 0.15f * (float) Math.sin(t * 2.2);
        p.setShader(new RadialGradient(cx, cy, u * 0.75f * pulse,
                new int[]{Color.argb(150, 229, 9, 20), Color.argb(40, 255, 140, 0), Color.TRANSPARENT},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        p.setAlpha((int) (255 * ease(t / 0.9f)));
        c.drawRect(0, 0, w, h, p);
        // vinheta
        p.setShader(new RadialGradient(cx, cy, Math.max(w, h) * 0.75f, Color.TRANSPARENT, Color.argb(220, 0, 0, 0), Shader.TileMode.CLAMP));
        p.setAlpha(255); c.drawRect(0, 0, w, h, p);
        // logo
        float in = ease((t - 0.15f) / 0.9f);
        float size = u * 0.19f;
        p.setShader(null); p.setTextSize(size); p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        p.setLetterSpacing(0.02f);
        String a = "Mengo", b = "Player";
        float wa = p.measureText(a), wb = p.measureText(b), x0 = cx - (wa + wb) / 2f;
        float y = cy + size * 0.35f + (1 - in) * u * 0.05f;
        c.save(); float sc = 0.9f + 0.1f * in; c.scale(sc, sc, cx, cy);
        p.setAlpha((int) (255 * in));
        p.setShadowLayer(size * 0.25f, 0, 0, Color.argb((int) (160 * in), 255, 120, 0));
        p.setShader(new LinearGradient(0, y - size, 0, y, Color.WHITE, Color.parseColor("#d9d9d9"), Shader.TileMode.CLAMP));
        c.drawText(a, x0, y, p);
        p.setShader(new LinearGradient(x0 + wa, y - size, x0 + wa + wb, y, Color.parseColor("#ff5a4e"), Color.parseColor("#e32219"), Shader.TileMode.CLAMP));
        c.drawText(b, x0 + wa, y, p);
        p.clearShadowLayer();
        // reflexo de luz atravessando o logo
        float sweep = ((t - 0.9f) % 2.4f) / 1.2f;
        if (t > 0.9f && sweep < 1f) {
            float sx = x0 - size + (wa + wb + 2 * size) * sweep;
            p.setShader(new LinearGradient(sx - size * 0.4f, 0, sx + size * 0.4f, 0,
                    new int[]{Color.TRANSPARENT, Color.argb(170, 255, 255, 255), Color.TRANSPARENT}, null, Shader.TileMode.CLAMP));
            p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
            c.drawText(a, x0, y, p); c.drawText(b, x0 + wa, y, p);
            p.setXfermode(null);
        }
        c.restore();
        // subtitulo
        float sub = ease((t - 0.6f) / 0.8f);
        p.setShader(null); p.setTextSize(u * 0.032f); p.setLetterSpacing(0.6f);
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setColor(Color.argb((int) (190 * sub), 220, 225, 240));
        String st = "IPTV PLAYER"; c.drawText(st, cx - p.measureText(st) / 2f, cy + size * 0.95f, p);
        p.setLetterSpacing(0f);
        // barra de carregamento com brilho deslizante
        float bw = u * 0.42f, bh = Math.max(3f, u * 0.006f), by = cy + size * 1.55f, bx = cx - bw / 2f;
        float bar = ease((t - 0.8f) / 0.6f);
        p.setColor(Color.argb((int) (50 * bar), 255, 255, 255));
        c.drawRoundRect(bx, by, bx + bw * bar, by + bh, bh, bh, p);
        float k = (t * 0.7f) % 1f, sx = bx + bw * k;
        p.setShader(new LinearGradient(sx - bw * 0.25f, 0, sx + bw * 0.05f, 0,
                new int[]{Color.TRANSPARENT, Color.parseColor("#e32219"), Color.parseColor("#ff5a4e")}, null, Shader.TileMode.CLAMP));
        p.setAlpha((int) (255 * bar));
        c.drawRoundRect(Math.max(bx, sx - bw * 0.25f), by, Math.min(bx + bw * bar, sx + bw * 0.05f), by + bh, bh, bh, p);
        p.setShader(null);
    }
}
