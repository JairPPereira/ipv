package com.unitv.player;

/** Interface MengoPlayer (HTML+CSS+JS+imagens) convertida em codigo Java. Gerado automaticamente. */
final class WebBundle {
    private WebBundle() {}
    private static String cache;
    static synchronized String html() {
        if (cache != null) return cache;
        StringBuilder b = new StringBuilder(3491433);
        WebBundle0.a(b);
        WebBundle1.a(b);
        WebBundle2.a(b);
        cache = b.toString();
        return cache;
    }
}
