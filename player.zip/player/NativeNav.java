package com.unitv.player;

import android.view.KeyEvent;

/**
 * Mapa nativo de teclas (controle remoto + teclado fisico) -> acoes do MengoPlayer.
 * Setas/OK/Enter/Espaco vao direto para o WebView (navegacao espacial em WebBundle).
 * ESC e BACKSPACE (fora de campos de texto) funcionam como VOLTAR, tratados na MainActivity.
 */
final class NativeNav {
    private NativeNav() {}

    static String forKey(int code) {
        switch (code) {
            case KeyEvent.KEYCODE_F1: case KeyEvent.KEYCODE_PROG_RED:    return "nav:home";
            case KeyEvent.KEYCODE_F2: case KeyEvent.KEYCODE_PROG_GREEN:  return "nav:live";
            case KeyEvent.KEYCODE_F3: case KeyEvent.KEYCODE_PROG_YELLOW: return "nav:vod";
            case KeyEvent.KEYCODE_F4: case KeyEvent.KEYCODE_PROG_BLUE:   return "nav:series";
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE: case KeyEvent.KEYCODE_MEDIA_PLAY:
            case KeyEvent.KEYCODE_MEDIA_PAUSE:        return "media:toggle";
            case KeyEvent.KEYCODE_MEDIA_STOP:         return "media:stop";
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD: return "media:ff";
            case KeyEvent.KEYCODE_MEDIA_REWIND:       return "media:rw";
            case KeyEvent.KEYCODE_MEDIA_NEXT: case KeyEvent.KEYCODE_CHANNEL_UP: return "ep:next";
            case KeyEvent.KEYCODE_SEARCH:             return "search";
            case KeyEvent.KEYCODE_MENU:               return "menu";
            case KeyEvent.KEYCODE_INFO: case KeyEvent.KEYCODE_GUIDE: case KeyEvent.KEYCODE_F11: return "fullscreen";
            case KeyEvent.KEYCODE_VOLUME_MUTE: case KeyEvent.KEYCODE_MUTE: return null; // sistema trata
            default: return null;
        }
    }

    /** Teclas que significam VOLTAR (alem do BACK do controle e do botao direito do mouse). */
    static boolean isBackKey(int code) {
        return code == KeyEvent.KEYCODE_ESCAPE || code == KeyEvent.KEYCODE_BUTTON_B;
    }
}
