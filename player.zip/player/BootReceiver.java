package com.unitv.player;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Abre o MengoPlayer ao ligar a TV, somente se o usuário ativou Android.setAutoStart(true). */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (!c.getSharedPreferences("mengoplayer", Context.MODE_PRIVATE).getBoolean("autostart", false)) return;
        Intent l = new Intent(c, MainActivity.class);
        l.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try { c.startActivity(l); } catch (Exception ignored) {}
    }
}
